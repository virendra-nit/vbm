
<?php require('header.php')?>
	
	<!--  headbar//////////////////////////////////////////-->
	<div class="headBar">
		<div class="container">
			<div class="breadCrumb hidden-xs">
				<a href="index-2.html">Home</a> / About us
			</div>
			<h1>HISTORY</h1>
		</div>
	</div>
	
	<!-- end  headbar//////////////////////////////////////////--> 
	
	<!--  welcome//////////////////////////////////////////-->
	
	<div class=" brownBG padding-top30">
		<div class="container">
			<h3>Vishva Bauddha Mahasangh </h3>
			<div class="row">
				<div class="col-xs-12  padding-bot20">
					It is a humble request that you yourself become a member of the World Buddhist Federation and motivate others to become members, so that all of us together can fulfill the mission of the Buddhist great men, Buddhist nation, Baba Saheb Dr. Ambedkar has said that We have to realize that the duty of a Buddhist nation is not just to be a good Buddhist but it is his duty to promote the promotion of Buddhism. You must believe that propagating the propagation of Buddhism is the biggest service to humanity. Our slavery and misery have forced us to rebuild our society, to make a rigorous and subtle analysis of our society and to accept the truth. Dare make him so strong and healthy that he is capable of facing any attack. To bring unity in society and to bring unity in the society, to bring unity in ideas and feelings, we must end the arrangement of society and the society. We need to eliminate the unity of the society to bring uniformity to the thoughts and feelings. The aim is to define the objective that the creation of the Buddhist ruler nation can be done only when we have the real knowledge of our history Not because the future building is built only on the foundation of history. It is only from history that we know what we are and what we should be. The World's Buddhist Federation, the great Buddhist emperor Ashoka, Bodhisatta Ravidas ,Bodhisatta Kabir , Jyotiba Rao Phule, Savitri bai Phule, Periyar Radha Swami , Naikar , Chhatrapati Shahuji Maharaj ,Sant Baba Gadke, Mata Ramabai Ambedkar , Bodhisattva Baba Saheb Dr. Bhimrao Ambedkar , Bahujan Nayak, only the Buddhist greats, including the Bahujan Nayak Kansiram, consider their ideal. The aim of Buddhist greats is to create a Buddhist nation. The Buddhist nation means equality, independence, and building an ideal nation based on democratic values such as fraternity.				</div>
			</div>
			<div class="row about-history-topBG">
				<div class="col-md-9  padding-bot50">
					<p>
	 <strong>Establishment</strong>Buddha Purnima Monday 4th May 2015 <strong></strong> .</p>
<p>&nbsp;
	</p>
<p>
	<strong>Our Aim</strong></p>

	<li>
		Complete mission of Bodhisattva Baba Saheb Dr. Bhimrao Ambedkar to fulfill the creation of Buddhist nation</li>
		<strong>Subject of seminar cadre</strong></p>

	<li>
		Bodhisattva Baba Saheb Doctor Bhimrao Ambedkar's overall mission is to build a lot of nation. It is the responsibility and responsibility of all of us</li>
	
			</div>
		</div>
	</div>
	
	<!--  end welcome//////////////////////////////////////////--> 
	
	<!--  content2//////////////////////////////////////////-->
	<div class="historyBG2">
		<div class="container">
			<div class="whiteHead">
				World organization of World Confederation
			</div>
			<div class="padding-bot40">
				<p>
				<strong>Buddha Youth Union</strong></p>
	<li>
		Every village village is formed by a very young association through which the Trishyan program is organized around 5:00 am every Sunday in the premises of Buddha Vihar Bodhisattva Baba Saheb Dr. Bhimrao Ambedkar statue or Buddhist Mahabharos. Discussion about the reading of Buddha Vandana Trisharan Panchsheel Buddhist literature by the Panchsheel flag and the propagation of the propagation of Buddhism Is discussed </li>
		<strong>Bodhisattva Dr. Ambedkar Education Society</strong></p>
	<li>
		The society is engaged in educating the students and teaching the importance of education in every village of the village, and according to the requirement, material related to tuition and education is made available to the students.</strong></p>
	<li>
	<strong>Bodhisattva Dr. Ambedkar Health Society</strong></p>
		Free health camps are organized from time to time in every village mohalla, in which free distribution of prescription drugs and health related advice and information is given. </li>
				</div>
		
	</div>
			</div>
		</div>
	</div>
	
	<!-- end content2//////////////////////////////////////////--> 
	<?php require('footer.php')?>