
<?php require('header.php')?>

  <!--  headbar//////////////////////////////////////////-->
	<div class="headBar">
		<div class="container">
			<div class="breadCrumb hidden-xs">
				<a href="index-2.html">Home</a> / About us
			</div>
			<h1>EXECUTIVE COUNCIL</h1>
		</div>
	</div>
	
	<!-- end  headbar//////////////////////////////////////////--> 
	
	<!--  container//////////////////////////////////////////-->
	<div class="container padding-bot50">
		<div class="clear clearfix">
			<div class="item-Container padding-top50">
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000012_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Mr. Phan Wannamethee (President)						</div>
							<div>Thailand</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000013_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Venerable Pu Zheng						</div>
							<div>China</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000006_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Rev. Yoshiharu Tomatsu						</div>
							<div>Japan</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000014_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Reverend Su-Gak (Kim Chi Won)						</div>
							<div>South Korea</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000007_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Dr. Yo, Hsiang-chou						</div>
							<div>Chinese Taipei</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000005_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Mrs. Camellia Darmawan						</div>
							<div>Indonesia</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000015_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Dato’ Ang Choo Hong						</div>
							<div>Malaysia</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000016_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Mr. Chandra Nimal Wakishta						</div>
							<div>Sri Lanka</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000010_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Mrs. Kanchana Soonsawad						</div>
							<div>Thailand</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000002_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Mr. Phallop Thaiarry (Secretary-General)						</div>
							<div>Thailand</div>												
					</div>
				</div>
								<div class="padding0 col-lg-2 col-md-3 col-sm-4  itemH borderGrey">
					<div>
						
						<img src="uploads/councils/011000017_01101.jpg">					</div>
					<div class="profileName">
						<div class="profileName-head">
							Ms. Pensri Roungpong (Treasurer)						</div>
							<div>Thailand</div>												
					</div>
				</div>
							</div>
		</div>
	</div>
	<!--  end container//////////////////////////////////////////--> 
 <?php require('footer.php')?>