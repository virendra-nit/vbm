<?php require('header.php')?>
     
     <!--  headbar//////////////////////////////////////////-->
     <div class="headBar">
       <div class="container">
         <div class="breadCrumb hidden-xs"><a href="index-2.html">Home</a></div>
         <h1>DONATION</h1>
       </div>
     </div>
   
     <!-- end  headbar//////////////////////////////////////////-->
     
     
      <!--  selectCountry //////////////////////////////////////////--><!-- end  selectCountry //////////////////////////////////////////-->
     
     <!--  pagination//////////////////////////////////////////--><!--  end pagination//////////////////////////////////////////-->
     
     
       <!--  container2//////////////////////////////////////////-->
       <div class="brownBG">
         <div class="container padding-bot50 padding-top50 clearfix donateBG">
           <div class="row">
             
             <div class="col-md-8 col-md-offset-4">
             <div class="rsuBlackHead padding-bot30">
               <p>As our organization continues to strengthen and develop, the demands  on  administration,  scope of purpose and  function  also expand proportionately.                 </p>
               <p>&nbsp;</p>
               <p>Thus, your kind donation will definitely support our organization to take further steps towards our aims and objectives in order to secure unity, solidarity, and brotherhood amongst Buddhists throughout the world numbering hundreds of millions for the prosperous years to come. </p>
             </div>
             <div class="rsuHeadBrown padding-bot10">How to Donate to our organization are as follow:</div>
<div class="padding-bot20">

<div class="padding-top10">
<h2>Bank Tranfer / Cheque / Bank Draft </h2>
        <ol><li> Pay by Cheque, Bank Draft or Money order, the beneficiary’s name is “The World Fellowship of  Buddhists” (WFB Contribution Fund)<br>
          <br>
        </li>
        <li>Pay via S.W.I.F.T. or Money transfer, the detail of payment is follow:<br>       
          <div class="text-Brown clear">
           <div class="row">
              <div class="col-md-3"><strong>Account number</strong></div>
              <div class="col-md-9">116-1-20131-5</div>
            </div>
            <div class="row">
              <div class="col-md-3"><strong>Name</strong></div>
              <div class="col-md-9">The World Fellowship of Buddhists</div>
            </div>
            <div class="row">
              <div class="col-md-3"><strong>Address</strong></div>
              <div class="col-md-9">616 Benjasiri Park soi Medhinivet offSoi Sukhumvit 24 Bangkok 10110 Thailand</div>
            </div>
            <div class="row">
              <div class="col-md-3"><strong>Bank’s name</strong></div>
              <div class="col-md-9">Krungsri Bank Public Company Limited  Sukhumvit 35 Branch</div>
            </div>
            <div class="row">
              <div class="col-md-3"><strong>S.W.I.F.T.</strong></div>
              <div class="col-md-9">AYUDTHBK   </div>
            </div>
		 </div>
        </li>
          </ol>
      </div>
      

  
</div>
             </div>
           </div>
         </div>
       </div>
<!--  end container2//////////////////////////////////////////-->


<?php require('footer.php')?>