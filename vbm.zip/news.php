<?php require('header.php')?>
	
	<!--  headbar//////////////////////////////////////////-->
	<div class="headBar">
		<div class="container">
			<div class="breadCrumb hidden-xs">
				<a href="index-2.html">Home</a> / News and Activity
			</div>
			<h1>News &amp; Activity</h1>
		</div>
	</div>
	
	<!-- end  headbar//////////////////////////////////////////--> 
	
	<!--  selectCountry //////////////////////////////////////////--><!-- end  selectCountry //////////////////////////////////////////--> 
	
	<!--  pagination//////////////////////////////////////////-->
	<div class="brownBG">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 clearfix btnPrev">
					<div class="row"><div class="col-xs-12 clearfix btnPrev"><a class="btnNext" href="newscf19.html?cid=001000005&amp;page=2"></a><div class="pageNumb"><a href="news4506.html?cid=001000005&amp;page=1"  class="pageNumb-selected">1</a>
<a href="newscf19.html?cid=001000005&amp;page=2">2</a>
<a href="news40a4.html?cid=001000005&amp;page=3">3</a>
<a href="news476d.html?cid=001000005&amp;page=4">4</a>
</div></div></div>				</div>
			</div>
		</div>
	</div>
	<!--  end pagination//////////////////////////////////////////--> 
	
	<!--  container2//////////////////////////////////////////-->
	<div class="container padding-bot40 clearfix">
		<div class="row">
			<div class="col-md-9 padding-top30">
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detail7ce3.html?id=002000088"><img src="uploads/news/002000088_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								24-28 May B.E. 2561 (2018)							</div>
                            							<div>
								<a class="newslink-head" href="news-detail7ce3.html?id=002000088">Visit Regional Centres in South Korea</a>
							</div>
							<div class="padding-top10">
								H.E. Phan Wannamethee, President of The WFB, assigned Mr. Phallop Thaiarry, Vice-President and Secretary-General, visited Regional Centres in South Korea for strengthening relationship from 24-28 May B.E. 2561 (2018).							</div>
						</div>
					</div>
				</div>
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detail3f3b.html?id=002000087"><img src="uploads/news/002000087_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								28 May B.E. 2561 (2018)							</div>
                            							<div>
								<a class="newslink-head" href="news-detail3f3b.html?id=002000087">Visitor from the Buddhist Society of India</a>
							</div>
							<div class="padding-top10">
								Mr. Rajratna Ambedkar from the Buddhist Society of India, one of 42 Regional Centres of The WFB in India led the group to visit The WFB Headquarters on 28 May B.E. 2561 (2018).&nbsp; They are welcomed by Mrs. Kanchana Soonsawad (Executive Council Member), Mrs. Sawanee Chuensumran (Deputy Secretary-General), Rear Admiral Isara Yimpanich (Assistant Secretary-General).							</div>
						</div>
					</div>
				</div>
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detailc16d.html?id=002000081"><img src="uploads/news/002000081_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								26-30 March B.E. 2561 (2018)							</div>
                            							<div>
								<a class="newslink-head" href="news-detailc16d.html?id=002000081">The 91st Executive Council Meeting</a>
							</div>
							<div class="padding-top10">
								It was held at The WFB Headquarters in Bangkok from 26-30 March B.E. 2561 (2018) at Sanya Dharmasakti Auditorium.							</div>
						</div>
					</div>
				</div>
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detaild155.html?id=002000079"><img src="uploads/news/002000079_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								28 Feb B.E. 2561 (2018)							</div>
                            							<div>
								<a class="newslink-head" href="news-detaild155.html?id=002000079">Reverend Beob Ahn of Ansim Jeongsa and Mr. Lim Seo Gyo of World Fellowship Buddhists Korea Regional Centre visited The WFB Headquarters</a>
							</div>
							<div class="padding-top10">
								Reverend Beob Ahn, Head of An Sim Jeongsa, Mr. Lim Seon Gyo, Honorary Chairman of World Fellowship of Korea Regional Centre, and groups paid a courtesy visit to H.E. Phan Wannamethee, President of The WFB, and visited The WFB Headquarters.							</div>
						</div>
					</div>
				</div>
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detail469b.html?id=002000078"><img src="uploads/news/002000078_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								27 January B.E. 2561 (2018)							</div>
                            							<div>
								<a class="newslink-head" href="news-detail469b.html?id=002000078">Merit Making for New Year and the President of The WFB Gracious Age</a>
							</div>
							<div class="padding-top10">
								The WFB Headquarters organized a Merit Making for New Year and the President of The WFB&rsquo;s Gracious Age at its Headquarters in Bangkok, Thailand on 27 January B.E. 2561 (2018).							</div>
						</div>
					</div>
				</div>
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detailcdcc.html?id=002000077"><img src="uploads/news/002000077_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								26 January B.E. 2561 (2018)							</div>
                            							<div>
								<a class="newslink-head" href="news-detailcdcc.html?id=002000077">Blankets Distribution</a>
							</div>
							<div class="padding-top10">
								Although the very low temperature that hit most parts of Thailand was subsided, people is still affected by a very cold weather.&nbsp; Further assistance provided to all monks and people was still going on.							</div>
						</div>
					</div>
				</div>
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detaile0f3.html?id=002000075"><img src="uploads/news/002000075_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								15 January B.E. 2561 (2018)							</div>
                            							<div>
								<a class="newslink-head" href="news-detaile0f3.html?id=002000075">Blankets Distribution</a>
							</div>
							<div class="padding-top10">
								A very low temperature struck most parts of Thailand and seriously affected in the North and Northeast of Thailand, on 15 January B.E. 2561 (2018) Her Majesty Queen Sirikit of the King Rama IX graciously granted H.E. Phan Wannamethee, as Secretary of Thai Red Cross Society, and also President of The WFB, represented Her Majesty distributed 1,000 blankets to monks and people							</div>
						</div>
					</div>
				</div>
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detailaf3b.html?id=002000074"><img src="uploads/news/002000074_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								16 January B.E. 2561 (2018)							</div>
                            							<div>
								<a class="newslink-head" href="news-detailaf3b.html?id=002000074">Secretary of International Buddha Education Institute visited The WFB Headquarters</a>
							</div>
							<div class="padding-top10">
								Mr. A.H. Otani, Secretary General /Chief Executive Officer (in grey suit), and two executives of International Buddha Education Institute (a Regional Centre of The WFB in India), visited The WFB Headquarters							</div>
						</div>
					</div>
				</div>
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detailaffe.html?id=002000072"><img src="uploads/news/002000072_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								21 November B.E. 2560 (2017)							</div>
                            							<div>
								<a class="newslink-head" href="news-detailaffe.html?id=002000072">Won-Buddhism opened a temple in Thailand and visited The WFB Headquarters</a>
							</div>
							<div class="padding-top10">
								H.E. Phan Wannamethee, President of The WFB, Mr. Phallop Thaiarry, Secretary-General, and Mrs. Kanchana Soonsawad, Executive Council Member, attended the opening ceremony of Won-Buddhism temple in Bangkok, Thailand held on 21 November B.E. 2560 (2017).&nbsp; It is hoped that this temple will provide a chance for Korean and Thai people to learn each other culture and tradition thru Buddhism.							</div>
						</div>
					</div>
				</div>
								<div class="greyBorderLine">
					<div class="row padding-top30">
						<div class="col-sm-5 padding-bot30">
														<a href="news-detail6ac9.html?id=002000070"><img src="uploads/news/002000070_00201.jpg"></a>
													</div>
						<div class="col-sm-7 padding-bot30">
                        								<div class="news-date newsHead">
								19 October B.E. 2560 (2017							</div>
                            							<div>
								<a class="newslink-head" href="news-detail6ac9.html?id=002000070">Former Prime Dharma Master of Won-Buddhism and group of representative visited The WFB Headquarters</a>
							</div>
							<div class="padding-top10">
								On 19 October B.E. 2560 (2017) former Prime Dharma Master Emeritus, the Most Venerable Chwasan Nim, and his group from Won-Buddhism (a Regional Centre of The WFB in South Korea) visited The WFB Headquarters.							</div>
						</div>
					</div>
				</div>
							</div>
			<div class="col-md-3 hidden-sm hidden-xs">
				<div class="submenuHead">
					NEWS &amp; ACTIVITY
				</div>
				<ul class="submenuRight">
											<li><a href="newsa3dc.html?cid=001000004">Dhamma Talks</a></li>
											<li><a href="news0efd.html?cid=001000005">Headquarters</a></li>
											<li><a href="newsb1ae.html?cid=001000006">Regional Centres</a></li>
									</ul>
			</div>
		</div>
	</div>
	<!--  end container2//////////////////////////////////////////--> 
	
	<!--  pagination//////////////////////////////////////////-->
	<div class="brownBG">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 clearfix btnPrev">
					<div class="row"><div class="col-xs-12 clearfix btnPrev"><a class="btnNext" href="newscf19.html?cid=001000005&amp;page=2"></a><div class="pageNumb"><a href="news4506.html?cid=001000005&amp;page=1"  class="pageNumb-selected">1</a>
<a href="newscf19.html?cid=001000005&amp;page=2">2</a>
<a href="news40a4.html?cid=001000005&amp;page=3">3</a>
<a href="news476d.html?cid=001000005&amp;page=4">4</a>
</div></div></div>				</div>
			</div>
		</div>
	</div>
	<!--  end pagination//////////////////////////////////////////--> 
	
	<?php require('footer.php')?>