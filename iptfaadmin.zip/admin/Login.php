<!DOCTYPE HTML>
<html>
<head>
<title>IPTFA</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery.min.js"> </script>
<script src="js/bootstrap.min.js"> </script>
</head>
<body style="background:url(images/12.jpg);">
	<div class="login">
		<h1> <a href="Dashboard" style="text-shadow: 4px 2px 5px #03334c;color:#000;">IPTFA </a></h1>
		<div class="login-bottom">
			<h2>Login</h2>
			<form action="con2.php" method="post">
			<div>
				<div class="login-mail">
					<input type="text" name="txtadmin" placeholder="Email" required="">
					<i class="fa fa-envelope"></i>
				</div>
				<div class="login-mail">
					<input type="password" name="txtpassword" placeholder="Password" required="">
					<i class="fa fa-lock"></i>
				</div>

			
			</div>
			<div class="login-do">
				<label class="hvr-shutter-in-horizontal login-sub">
					<input type="submit" value="login">
					</label>
			</div>
			
			<div class="clearfix"> </div>
			</form>
		</div>
	</div>
		<!---->
<div class="copy-right">
            <p style="color:#000000;"> &copy; 2018 IPTFA | Design by <a href="http://www.hypezen.com/" target="_blank">Hypezen Technologies</a> </p>	    </div>  
<!---->
<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
</body>
</html>

